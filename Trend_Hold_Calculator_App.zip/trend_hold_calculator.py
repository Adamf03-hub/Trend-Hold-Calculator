
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import yfinance as yf

st.set_page_config(page_title="Trend Hold Strategy Calculator", layout="centered")
st.title("🧮 Trend Hold Trading Plan Calculator with Auto-Analysis")

st.sidebar.header("🔧 Strategy Inputs")
account_size = st.sidebar.number_input("Account Size ($)", value=600)
leverage = st.sidebar.number_input("Leverage", value=6)
entry_price = st.sidebar.number_input("Starter Entry Price", value=42.0)
add1_price = st.sidebar.number_input("Add #1 Price", value=50.0)
add2_price = st.sidebar.number_input("Add #2 Price", value=60.0)
stop_price = st.sidebar.number_input("Stop Loss Price", value=38.0)
scale_out1 = st.sidebar.number_input("Scale-Out 1 Target", value=76.0)
scale_out2 = st.sidebar.number_input("Scale-Out 2 Target", value=90.0)
final_target = st.sidebar.number_input("Final Target Price", value=100.0)

symbol = st.sidebar.text_input("Ticker Symbol (for float, RVOL, MACD)", value="INKT")
uploaded_chart = st.sidebar.file_uploader("Upload Chart Screenshot (optional)", type=["png", "jpg", "jpeg"])

# Buying power & allocation
buying_power = account_size * leverage
starter_bp = buying_power * 0.3
add1_bp = buying_power * 0.3
add2_bp = buying_power * 0.4

starter_shares = int(starter_bp // entry_price)
add1_shares = int(add1_bp // add1_price)
add2_shares = int(add2_bp // add2_price)

total_shares = starter_shares + add1_shares + add2_shares
total_cost = (starter_shares * entry_price) + (add1_shares * add1_price) + (add2_shares * add2_price)
avg_entry = total_cost / total_shares if total_shares > 0 else 0
risk_per_share = avg_entry - stop_price
total_risk = risk_per_share * total_shares

profit1 = (scale_out1 - avg_entry) * int(total_shares * 0.25)
profit2 = (scale_out2 - avg_entry) * int(total_shares * 0.25)
profit3 = (final_target - avg_entry) * int(total_shares * 0.5)
total_profit = profit1 + profit2 + profit3

st.subheader("📊 Trading Plan Summary")
st.markdown(f"""
- **Buying Power:** ${buying_power:,.2f}
- **Starter Shares:** {starter_shares} @ ${entry_price}
- **Add #1 Shares:** {add1_shares} @ ${add1_price}
- **Add #2 Shares:** {add2_shares} @ ${add2_price}
- **Total Shares:** {total_shares}
- **Average Entry Price:** ${avg_entry:.2f}
- **Stop Loss:** ${stop_price}
- **Total Risk:** ${total_risk:.2f}

### 📈 Profit Target Breakdown:
- Scale-Out 1 (@ ${scale_out1}): ${profit1:.2f}
- Scale-Out 2 (@ ${scale_out2}): ${profit2:.2f}
- Final Exit (@ ${final_target}): ${profit3:.2f}
- **Total Potential Profit:** ${total_profit:.2f}
""")

# Auto-Fetch Float, RVOL and MACD (placeholder using yfinance)
try:
    st.subheader(f"📉 Auto-Fetch Data for {symbol.upper()}")
    data = yf.Ticker(symbol).history(period="5d", interval="1h")
    if not data.empty:
        data["EMA9"] = data["Close"].ewm(span=9).mean()
        data["EMA20"] = data["Close"].ewm(span=20).mean()
        data["MACD"] = data["EMA9"] - data["EMA20"]
        data["Signal"] = data["MACD"].ewm(span=9).mean()
        last_macd = data["MACD"].iloc[-1]
        last_signal = data["Signal"].iloc[-1]

        st.markdown(f"- **MACD:** {last_macd:.2f}")
        st.markdown(f"- **Signal Line:** {last_signal:.2f}")
        st.markdown(f"- **MACD Crossover?** {'Yes ✅' if last_macd > last_signal else 'No ❌'}")
    else:
        st.warning("No intraday data available for MACD. Try a different symbol.")
except Exception as e:
    st.warning(f"Data fetch failed: {e}")

# Display uploaded chart
if uploaded_chart:
    st.subheader("🖼 Uploaded Chart")
    st.image(uploaded_chart, use_column_width=True)
